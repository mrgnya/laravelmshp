<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Film;
class ViewController extends Controller
{
    public function showAll(){
        $films=Film::all();
        return view('index', ['films'=>$films]);
        
    }
    public function add(Request $request){
        $films = new Film;

        $films->title = $request->title;
        $films->description = $request->description;
        $films->season = $request->season;
        $films->part = $request->part;
        $films->save();
        return redirect('/admin');
    }
    public function delete($id){
        Film::destroy($id);
        return redirect('/admin');
    }
    public function edit($id){
        $films=Film::find($id);
        $films->title=$title;
        $films->save();
        return redirect('/admin');
    }
}
