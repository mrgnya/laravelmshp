<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="/css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro&display=swap" rel="stylesheet">
    <title>Chill Films | Вход</title>
</head>
<body>
<header>
        <a href="/"><h1>Chill films</h1></a>
        <nav>
            <ul>
                <a href="/registration"><li>Регистрация</li></a>
                <a href="/login"><li>Вход</li></a>
               <a href="/feedback"><li>Поддержка</li></a>
            </ul>
        </nav>
        </header>
        ТУт вход на сайт
</body>
</html>