<?php

Route::get('/', function () {
    return view('home');
});

Route::get('/content/{list}', function ($list) {
    if($list=='registration'){
        return view('reg');
    }elseif($list=='login'){
        return view('log');
    }elseif($list=='feedback'){
        return view('fb');
    }elseif($list=='admin'){
        return view('admin');
    }else
        return view('list');
    });
Route::get('/content/{list}/{film_name}', function ($list, $film_name) {
        return view('list');
    });
Route::get('/content/{list}/{film_name}/{season}', function ($list, $film_name) {
        return view('list');
    });
Route::get('/content/{list}/{film_name}/{season}/{part}', function ($list, $film_name, $season, $part) {
        return view('part');
    }); 





Route::post('/admin/add', 'ViewController@add');

Route::post('/admin', 'ViewController@showAll');

Route::post('/admin/delete/{id}', 'ViewController@delete');

Route::post('/admin/edit/{id}', 'ViewController@edit');


Route::get('/admin', function () {
        return view('admin');
    });


Route::get('/admin/add', function () {
        return view('add');
    });

Route::get('/admin/delete/{id}', function ($id) {
        return view('delete');
    });
Route::get('/admin/edit/{id}', function ($id) {
        return view('edit');
    });

